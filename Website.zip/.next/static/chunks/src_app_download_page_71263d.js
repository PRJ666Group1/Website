(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_download_page_71263d.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_download_page_71263d.js",
  "chunks": [
    "static/chunks/node_modules_next_dist_91fa56._.js",
    "static/chunks/src_app_download_page_570efc.js",
    "static/chunks/src_98befc._.css"
  ],
  "source": "dynamic"
});
