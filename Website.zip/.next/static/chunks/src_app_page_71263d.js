(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_71263d.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_71263d.js",
  "chunks": [
    "static/chunks/_d051b1._.js",
    "static/chunks/src_6f2870._.css"
  ],
  "source": "dynamic"
});
