(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_registration_page_71263d.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_registration_page_71263d.js",
  "chunks": [
    "static/chunks/node_modules_979f66._.js",
    "static/chunks/src_bf1f08._.js",
    "static/chunks/src_108ae8._.css"
  ],
  "source": "dynamic"
});
