(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_registration_page_tsx_f221bd._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_registration_page_tsx_f221bd._.js",
  "chunks": [
    "static/chunks/node_modules_bcc687._.js",
    "static/chunks/src_app_registration_page_tsx_47c25e._.js",
    "static/chunks/src_components_b00a69._.css"
  ],
  "source": "dynamic"
});
