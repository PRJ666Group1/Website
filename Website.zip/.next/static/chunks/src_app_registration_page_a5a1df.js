(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_registration_page_a5a1df.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_registration_page_a5a1df.js",
  "chunks": [
    "static/chunks/node_modules_51c002._.js",
    "static/chunks/src_app_registration_page_8c7cfc.js",
    "static/chunks/src_components_b00a69._.css"
  ],
  "source": "dynamic"
});
