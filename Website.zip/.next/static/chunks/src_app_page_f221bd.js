(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_f221bd.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_f221bd.js",
  "chunks": [
    "static/chunks/node_modules_next_dist_91fa56._.js",
    "static/chunks/src_app_page_19ad6a.js",
    "static/chunks/src_6f2870._.css"
  ],
  "source": "dynamic"
});
